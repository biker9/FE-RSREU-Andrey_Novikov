var myname = "Andrey";
var mylastname = "Novikov"
var myold = "20"
alert(myname); 
alert(mylastname);
alert(myold);